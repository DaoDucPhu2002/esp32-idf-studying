#include "HWConfig.h"
#include "TEE_EC200.h"

const char ssid[] = "GSafe check";//"st-marco2020";
const char password[] =  "@12345678"; // 

// const char ssid[] = "Dung Le";//"st-marco2020";
// const char password[] =  "@12345678"; // 

const char mqttServer[] = "test.api.lctech.vn";
const int   mqttPort = 1884;
const char mqttUser[] = "lctech_rmq";
const char mqttPassword[] = "lctechrmq123@";

char mqtt_server_test[] = "test.mosquitto.org";
int mqtt_port_test = 1883;

char topicSever[] = "mmm/GSafe_v3/data"; // mmm/GSafe_v3_data_4g/data
char txt_subscribe[] = "mmm/123456789012/cmd";
char topicSever4G[] = "mmm/GSafe_v3_4g/data";
//char txt_subscribe[] = "mmm/123456789012/cmd"

#define OTA_CURRENT_VERSION "22.10.024"
const char* ota_uri = "http://api.lctech.vn/firmware/esp32/OTA";
// char* ESP_ID = "123456789012";  
char ESP_ID[] = "123456789012";  
char IMEI[]   = "000000000000000"; 

Ticker ticker;

WiFiClient espClient;
PubSubClient mqtt(espClient);

uint8_t checkBoard = 0;

uint32_t lastcheckOTA;

int error_mqtt;
unsigned int lenth;
uint32_t lastTimeWifi;
uint8_t autoWifi=0,autoSsid;
#define timeloopOTA (1000 * 60 * 5)
bool in_smartconfig = false;
bool net4Gconnected = false,WifiConnected = false,rfOk=false;

extern EC200 gsm;

static const char GSM_OK[] PROGMEM    = "OK" GSM_NL;
static const char GSM_ERROR[] PROGMEM = "ERROR" GSM_NL;
String MODEM_OK = "OK";
String MODEM_ERROR  = "ERROR";

static const char OK_RESPOND[] PROGMEM    = "OK";
static const char PRODUCT_ID[] PROGMEM    = "ATI\r\n";
static const char MQTT_CONFG[] PROGMEM = "AT+QMTCFG=recv/mode,0,0,1";

#define PWR_ON_4G      1  // ON = 1, Start On = 0;
#define PWR_OFF_4G     4  // OFF = 4, Start Off = 3;

hw_timer_t * timer = NULL;
volatile SemaphoreHandle_t timerSemaphore;
portMUX_TYPE timerMux = portMUX_INITIALIZER_UNLOCKED;

uint32_t timeDelay4G, timeOut4G;
uint8_t autoInit4G,stepAuto4G,keyTest;

uint32_t Vbat,holdCharg;
uint8_t cntAdc,numBytesSave,deviceStatus,lenHexString;
uint16_t numTask1,cntDisconnect,numTaskS,numTimeSend4G;
uint32_t timeLoopAlarm,timeLoopStatus,timeLoopBAT,timeAutoBat;
uint32_t lastPress = 0,lastPressReset;
bool keyBell;
uint16_t holdKey;

// memory EEPROM
// 0-99 wifi
// 100 - 200, 100 check value of setting
// 

#define EEPROM_SETTING  100
// #define TIME_ALARM_ON    3000
// #define TIME_ALARM_OFF   2000

uint32_t timeAlarmOn,timeAlarmOff,timeActiveAlarm,timeAlarm,timeCheckAlarm;
//#define TIME_ALARM      (timeAlarmOn + timeAlarmOff)

#define TIME_CHECK_STATUS   100
#define TIME_CHECK_ALRAM    100
#define TIME_LOOP_WIFI      30000
// #define TIME_ACTIVE_ALARM   3000
#define TIME_HOLD_SENSOR    (timeActiveAlarm/TIME_CHECK_ALRAM)
#define TIME_WIFI           (TIME_LOOP_WIFI/TIME_CHECK_ALRAM)

uint8_t __attribute__((aligned(4))) dataload[numBytes]; 

uint8_t HexString[sizeof(dataload) * 2]; //2 nibbles/byte + null terminator

typedef union type8to32
{
    uint8_t uint8[16];
    uint16_t uint16[8];
    uint32_t uint32[4];
};
type8to32  eepRead;

struct gsafe_msg_data { // total = 35 byte
  uint8_t alarmStatus;        //  1        
  uint16_t batVoltage;        //  2 
  uint8_t batPercent;         //  1 
  uint8_t pwStatus;           //  1 
  uint8_t Status;             //  1 
  uint8_t LEDStatus;          //  1 
  int8_t rssi4G;              //  1 
  int8_t rssiWF;              //  1 
  uint16_t sensorEOL;         //  2
  uint16_t sensorStatus;      //  2  
  uint8_t lineStatus[numLine];
  uint16_t lineNotUse;
  uint8_t holdStatus[numLine];
  uint8_t keySensor[numLine], timeLow[numLine], timeHigh[numLine], timeHold[numLine];
  bool enableBell;             //  1 
  bool powerBAT; 
  uint8_t startCheckAlarm; 
  uint16_t timeCounter;
  uint16_t VolLowPwBAT;
  int8_t lowRssiWiFi,keyTest;
  uint8_t relayStatus;
  uint32_t zoneArlam;
  uint32_t zoneWarning;
  
};
struct gsafe_msg_data gdata ; //staMode

// typedef union type8to32
// {
//     uint8_t uint8[16];
//     uint16_t uint16[8];
//     uint32_t uint32[4];
// }__attribute__((packed));
type8to32  eepData;

void initStart(char rewrite){
  LAMP_OFF; BELL_ON; OUT1_OFF; OUT2_OFF; VBAT_OFF;
  LEDR_OFF;LEDG_OFF;
  gdata.enableBell = 1;
  gdata.powerBAT = 0;
  gdata.Status = NORMAL;
  gdata.lowRssiWiFi = -80;//75
  numBytesSave = 12;
  gdata.zoneArlam=0;
  gdata.zoneWarning=0;
  // rewrite = 1;
  if((EEPROM.read(EEPROM_SETTING-1) == 0xFF)|(rewrite)){
    timeAlarmOn = 3000;
    timeAlarmOff = 2000;
    timeAlarm = timeAlarm+timeAlarmOff;
    timeActiveAlarm = 3000;
    gdata.timeCounter = 8640;// 6day * 24h * 60min;
    gdata.VolLowPwBAT = 740;
    gdata.lineNotUse = 0;    
    GSafe_Setting_Save();
    debug("Save to EEPROM");
  }
  else {
    GSafe_Setting_Read();
    debug("Read from EEPROM");
  }
  // sendTimePCln("time Alarm On:",timeAlarmOn);
  // sendTimePCln("time Alarm Off:",timeAlarmOff);
  // sendTimePCln("time Active Alarm:",timeActiveAlarm);
  // digitalWrite(LED_D2, LOW);
  timeAutoBat = gdata.timeCounter*60*1000;
  BELL_OFF;
}
void InitIO(){
  // Init Output PIN
  pinMode(LED_D2, OUTPUT);
  pinMode(LEDG, OUTPUT);
  pinMode(LEDR, OUTPUT);
  pinMode(SA0, OUTPUT);
  pinMode(SA1, OUTPUT);
  pinMode(SA2, OUTPUT);
  pinMode(SA3, OUTPUT);
  pinMode(PWR_KEY, OUTPUT);
  pinMode(BOOT_EN, OUTPUT);
  pinMode(CHARGE, OUTPUT);
  pinMode(LAMP, OUTPUT);
  pinMode(BELL, OUTPUT);
  pinMode(RL_OUT1, OUTPUT);
  pinMode(RL_OUT2, OUTPUT);
  pinMode(BEEP, OUTPUT);
  // Init Input PIN
  pinMode(EOLINE, INPUT);
  pinMode(INSEN, INPUT);
  pinMode(RF_REMOTE,INPUT_PULLDOWN);
  BEEP_ON;
  // Init ADC
  //set the resolution to 12 bits (0-4096)
  EEPROM.begin(512);
  analogReadResolution(12);
  //net4Gconnected = false;
  initStart(0);
  // for(int i=0; i<numLine;i++)gdata.lineUse[i]=1;
}
void tick()
{  
  int state = digitalRead(LED_D2);  // get the current state of GPIO1 pin
  digitalWrite(LED_D2, !state);     // set pin to the opposite state
}
char h2c(char c){  
  return "0123456789ABCDEF"[0x0F & (unsigned char)c];
}
uint8_t updateHexString(uint8_t value, uint8_t index){
  HexString[index++]=h2c(value>>4);
  HexString[index++]=h2c(value&0x0F);
  return(index);
}
int convert_u8_hex(uint8_t* raw_data,uint8_t* conv_data, uint16_t data_length) {
  // char size_of_pack[data_length];
  uint16_t cnt_cvt = 0;
  char tempChars[3];//2 nibbles/byte + null terminator

  //check condition
  // if(data_length > sizeof(raw_data))
  //   return 1;
  // if(sizeof(conv_data) < (2* data_length))
  //   return 2;
  //convert char array to hex string
  memset(conv_data,0,sizeof(conv_data));
  for(cnt_cvt = 0; cnt_cvt < data_length; cnt_cvt ++) {
    sprintf(tempChars,"%02x",raw_data[cnt_cvt]);
    strncat((char*)conv_data, (char*)tempChars, 2);
  }
  return 0;
}
char* string2char(String ipString){ // make it to return pointer not a single char
  char* opChar = new char[ipString.length() + 1]; // local array should not be returned as it will be destroyed outside of the scope of this function. So create it with new operator.
  memset(opChar, 0, ipString.length() + 1);

  for (int i = 0; i < ipString.length(); i++)
    opChar[i] = ipString.charAt(i);
  return opChar; //Add this return statement.
}
void debug(String data)
{
  #ifdef DEBUG
  dbSerial.println(data);
  #endif // DEBUG
}
void debug(char* data)
{
  #ifdef DEBUG
    dbSerial.println(data);
  #endif // DEBUG
}
void sendHexPC(uint8_t hex){
  if(hex<16)dbSerial.print(('0'));
  dbSerial.print(hex,HEX);
  dbSerial.print(' ');
}
void sendToPCTest(){
    uint8_t numRssi;
    
    if(gdata.rssiWF!=0)  numRssi = 256-gdata.rssiWF;
    else numRssi = 0;
    dbSerial.print("ID;");                                        //0-2
    for(int line=0;line<12;line++) dbSerial.print(ESP_ID[line]);  //3-14
    dbSerial.print("-");
    for(int line=0;line<15;line++) dbSerial.print(IMEI[line]);    //16-30
    // dbSerial.print(" Status:"); dbSerial.print(gdata.Status);
    // dbSerial.print(" PS:");dbSerial.print(gdata.pwStatus);
    // if(gdata.pwStatus&PW_ACIN) dbSerial.print(" AC_OK"); else dbSerial.print(" AC_OF");
    // if(gdata.pwStatus&PW_CHARG) dbSerial.print(" CH_ON"); else dbSerial.print(" CH_OFF");
    // if(gdata.pwStatus&PW_BAT) dbSerial.print(" PW_BAT"); else dbSerial.print(" PW_AC");
    // if(gdata.pwStatus&BAT_OK) dbSerial.print(" BAT_OK:"); else dbSerial.print(" BAT_ER:");
    dbSerial.print("-");dbSerial.print(gdata.batVoltage/100);dbSerial.print(gdata.batVoltage/10%10);dbSerial.print(gdata.batVoltage%10); //34
    // dbSerial.print(gdata.batPercent);dbSerial.print('%');
    dbSerial.print("-");dbSerial.print(WifiConnected);dbSerial.print(numRssi/10);dbSerial.print(numRssi%10);    //  38
    // dbSerial.print(key_adc/1000);dbSerial.print(key_adc/100%10);dbSerial.print(key_adc/10%10);dbSerial.print(key_adc%10);
    numRssi = gdata.rssi4G;
    if(numRssi>99)numRssi=0;
    dbSerial.print("-"); dbSerial.print(net4Gconnected);dbSerial.print(numRssi/10);dbSerial.print(numRssi%10);  //  42 
    // sendTimePC(" Status:",gdata.Status);  
    dbSerial.print(rfOk+keyTest*2);    // 43
    for(int line=0;line<numLine;line++){
      // dbSerial.print(line+1); dbSerial.print(": ");
      dbSerial.print(gdata.lineStatus[line]);   // 44-59
    }     // 59
    // // dbSerial.println();
    // dbSerial.print("-");
    // dbSerial.write(gdata.zoneArlam/256); dbSerial.write(gdata.zoneArlam%256);
    // // dbSerial.print(gdata.zoneArlam);
    // dbSerial.print("-");
    // dbSerial.write(gdata.zoneWarning/256);  dbSerial.write(gdata.zoneWarning%256);
    // dbSerial.print(gdata.zoneWarning);
    uint16_t adc = analogRead(VBAT_FB); // VBAT_FB  CH_AC
    dbSerial.print(" "); dbSerial.print(adc); 
    adc = analogRead(CH_AC); // VBAT_FB  CH_AC   KEY_IN
    dbSerial.print(" "); dbSerial.print(adc);
    if(gdata.pwStatus&PW_ACIN) dbSerial.print(" AC_OK"); else dbSerial.print(" AC_OF");
    if(gdata.pwStatus&PW_CHARG) dbSerial.print(" CH_ON"); else dbSerial.print(" CH_OFF");
    if(gdata.pwStatus&PW_BAT) dbSerial.print(" PW_BAT"); else dbSerial.print(" PW_AC");
    if(gdata.pwStatus&BAT_OK) dbSerial.print(" BAT_OK:"); else dbSerial.print(" BAT_ER:");
    dbSerial.println();
   // debug(HexString);
}
void sendToPC(){
  #ifdef DEBUG
    dbSerial.print("ID1:");
    for(int line=0;line<12;line++) dbSerial.print(ESP_ID[line]);
    dbSerial.print("-");
    for(int line=0;line<15;line++) dbSerial.print(IMEI[line]);
    dbSerial.print("-S"); dbSerial.print(gdata.Status);
    dbSerial.print("-P");dbSerial.print(gdata.pwStatus);
    // if(gdata.pwStatus&PW_ACIN) dbSerial.print(" AC_OK"); else dbSerial.print(" AC_OF");
    // if(gdata.pwStatus&PW_CHARG) dbSerial.print(" CH_ON"); else dbSerial.print(" CH_OFF");
    // if(gdata.pwStatus&PW_BAT) dbSerial.print(" PW_BAT"); else dbSerial.print(" PW_AC");
    // if(gdata.pwStatus&BAT_OK) dbSerial.print(" BAT_OK:"); else dbSerial.print(" BAT_ER:");
    dbSerial.print("-B");dbSerial.print(gdata.batVoltage/100);dbSerial.print(gdata.batVoltage/10%10);dbSerial.print(gdata.batVoltage%10);
    // dbSerial.print(gdata.batPercent);dbSerial.print('%');
    dbSerial.print("-W"); dbSerial.print(WifiConnected);dbSerial.print(',');dbSerial.print(String(gdata.rssiWF));
    dbSerial.print("-G:"); dbSerial.print(net4Gconnected);dbSerial.print(',');dbSerial.print(gdata.rssi4G);   
    // sendTimePC(" Status:",gdata.Status);  
    dbSerial.print("-L");
    for(int line=0;line<numLine;line++){
      // dbSerial.print(line+1); dbSerial.print(": ");
      dbSerial.print(gdata.lineStatus[line]);
      // dbSerial.print(" ");
    }
    // dbSerial.println();
    dbSerial.print("-A");
    dbSerial.print(gdata.zoneArlam);
    dbSerial.print("-W");
    dbSerial.print(gdata.zoneWarning);
    dbSerial.println();
   // debug(HexString);
  #endif // DEBUG
}
void sendTimePC(char* data,uint32_t time){
  #ifdef DEBUG
    dbSerial.print(data);
    dbSerial.print(time);
  #endif
}
void sendTimePCln(char* data,uint32_t time){
  #ifdef DEBUG
    dbSerial.print(data);
    dbSerial.println(time);
  #endif
}
/********************************** BEGIN Wifi Code *********************************************/
bool longPress()
{  
  if (millis() - lastPress > 3000 && ((digitalRead(PIN_BUTTON) == 0)|(key_press()==KEY_MODE))) {
    return true;
  } 
  else if ((digitalRead(PIN_BUTTON) == 1)&(key_press()!=KEY_MODE)) {
    lastPress = millis();
  }
  // if(key_press()==KEY_MODE) holdKey++;
  //   else holdKey = 0;
  return false;
}
bool longPressReset()
{  
  if (millis() - lastPressReset > 3000 && ((key_press()==KEY_CHECK))) {
    ESP.restart();
    return true;
  } 
  else if ((key_press()!=KEY_MODE)) {
    lastPressReset = millis();
  }
  // if(key_press()==KEY_MODE) holdKey++;
  //   else holdKey = 0;
  return false;
}
void enter_smartconfig()
{
  if (in_smartconfig == false) {
    in_smartconfig = true;
    WiFi.mode(WIFI_STA);
    ticker.attach(0.1, tick);
    WiFi.beginSmartConfig();
    debug("Enter smartconfig");
  }
}
void exit_smart()
{
  ticker.detach();
  LED_ON();
  in_smartconfig = false;
}
void initAsAccessPoint() {
WiFi.softAP("ESP32-Access Point"); // or WiFi.softAP("ESP_Network","Acces Point Password");
#ifdef DEBUG
Serial.println("AccesPoint IP: " + WiFi.softAPIP().toString());
#endif // DEBUG 
Serial.println("Mode= Access Point");
//WiFi.softAPConfig(local_ip, gateway, subnet); // enable this line to change the default Access Point IP address
delay(100);
}
void checkWiFiConnection() {
if (WiFi.status() != WL_CONNECTED) {
if (lastConnectedStatus == 1) Serial.println("WiFi disconnected\n");
lastConnectedStatus = 0;
Serial.print(".");
delay(500);
} else {
if (lastConnectedStatus == 0) {
Serial.println("Mode= Client");
Serial.print("\nWiFi connectd to :");
Serial.println(ssid);
Serial.print("\n\nIP address: ");
Serial.println(WiFi.localIP());

}
lastConnectedStatus = 1;
}

}
void smartConfig() {
  if (longPress()) {
    WiFi.mode(WIFI_STA);
    enter_smartconfig();
    // dbSerial.println("Enter smartconfig");
  }
  if (WiFi.status() == WL_CONNECTED && in_smartconfig && WiFi.smartConfigDone()) {
    exit_smart();
    #ifdef DEBUG
      dbSerial.println("Connected, Exit smartconfig");
      dbSerial.print("Wifi SSID:"); dbSerial.println(WiFi.SSID());
    #endif // DEBUG    
    write_EEPROM_Wifi();
  }
  else if (WiFi.status() != WL_CONNECTED && in_smartconfig == false)
  {
     WiFi_Connect();        /*Reconnect wifi */
  }
  else if(autoWifi>0){
    if(WiFi.status() == WL_CONNECTED){
      ticker.detach();
      #ifdef DEBUG
        dbSerial.println("WiFi connected");
        dbSerial.println("IP address: ");
        dbSerial.println(WiFi.localIP());
      #endif // DEBUG      
      ticker.detach();
      digitalWrite(LED_D2, HIGH);
      autoWifi = 0;
    }
  }
  else if (WiFi.status() == WL_CONNECTED) {
    if(gdata.rssiWF>gdata.lowRssiWiFi) mqttConnect();     
  }
}
void macRead(){
  uint8_t i=0;
  char macAdd[20];
  String txt=WiFi.macAddress(); //44:17:93:EF:D1:70

  dbSerial.println(txt);
  txt.toCharArray(macAdd, 18);
  memset(ESP_ID,0,sizeof(ESP_ID));
  // for(i=0;i<12;i++) ESP_ID[i]=0;
  for(i=0;i<6;i++)
  { 
    // MAC_ID += macAdd[i*2+j];
    // MAC_ID += macAdd[i*2+1+j];
    // ESP_ID += macAdd[i*2+j];
    // ESP_ID += macAdd[i*2+1+j];
    ESP_ID[i*2]= macAdd[i*3];//h2c(macAdd[i]>>4);
    ESP_ID[i*2+1]= macAdd[i*3+1];//h2c(macAdd[i]);
  }  
  // text = "mmm/" + MAC_ID + "/cmd";
  for(i=0;i<12;i++) txt_subscribe[i+4] = ESP_ID[i]; 
  // dbSerial.print("subscribe:");  dbSerial.println(txt_subscribe);//macAdd) ;  
  dbSerial.print("MAC:"); dbSerial.println(ESP_ID) ;
}
void delayWifi(void){
  if((autoWifi==1)&((millis() - lastTimeWifi)>=500)){
    autoWifi=2;
    lastTimeWifi = millis();
  }
  else if((autoWifi>1)&((millis() - lastTimeWifi)>=1000)){
    autoWifi++;
    if(autoWifi>60)autoWifi=0;
    lastTimeWifi = millis();    
  }  
}
void WiFi_Connect() {  
  if(autoWifi==0){
    WiFi.mode(WIFI_OFF);      //Disconnect wifi
    autoWifi = 1;
    ticker.attach(0.5, tick);
  }
  else if(autoWifi==2){  
    //attempt to connect to Wifi network
    WiFi.mode(WIFI_STA); 
    debug("Connecting to WiFi..");
//    dbSerial.println(ssid);
    WiFi.begin();//ssid,password);
    debug(ssid);
    autoWifi = 3;
//   dbSerial.println("Connecting to WiFi..");
//   dbSerial.println(WiFi.SSID());
  }
  delayWifi();
}
void mqttConnect() {
  if(mqtt.connected())return;
  mqtt.setServer(mqttServer, mqttPort);
  mqtt.setCallback(callback);
  delay(10);
  while (!mqtt.connected()) {
    debug("Connecting to MQTT...");

    if (mqtt.connect(ESP_ID, mqttUser, mqttPassword )) {
      debug("connected");  
    } else {
      #ifdef DEBUG
      dbSerial.print("failed with state ");
      dbSerial.println(mqtt.state());
      #endif // DEBUG
      error_mqtt++;
      if(error_mqtt>10){
        error_mqtt=0;
        ESP.restart();
      }
    }
  }
  if (mqtt.connected()) {
    #ifdef DEBUG
    dbSerial.print("subscribe to:");
    dbSerial.println(txt_subscribe);
    #endif // DEBUG
    mqtt.subscribe(txt_subscribe);
    // dbSerial.println(ESP_ID);
  }
}
void ota_update(){
  if(millis()-lastcheckOTA>timeloopOTA){
    lastcheckOTA = millis();  
    if ((WiFi.status() == WL_CONNECTED)) {
      dbSerial.println("start OTA update");
      WiFiClient client;
      // t_httpUpdate_return ret = httpUpdate.update(client, ota_uri);
      t_httpUpdate_return ret = httpUpdate.update(client, ota_uri, OTA_CURRENT_VERSION);
      switch (ret) {
        case HTTP_UPDATE_FAILED:
          dbSerial.printf("HTTP_UPDATE_FAILED Error (%d): %s\n", httpUpdate.getLastError(), httpUpdate.getLastErrorString().c_str());
          break;
  
        case HTTP_UPDATE_NO_UPDATES:
          dbSerial.println("HTTP_UPDATE_NO_UPDATES");
          break;
  
        case HTTP_UPDATE_OK:
          dbSerial.println("HTTP_UPDATE_OK");
          break;
      }
    }
  }
}
void smartUpdateOTA(){ // Smart config, update OTA, Auto connect Wifi
  smartConfig();
  // run ota update
  if((millis() - lastcheckOTA) > timeloopOTA){
    lastcheckOTA = millis();
    // numUpdateOTA++;
    // if(numUpdateOTA>3){
      // numUpdateOTA = 0;  
//      saveData();
    // }
    ota_update();
  }
  mqtt.loop();
}
void sendToSever()
{    //this section send via Wifi
  if(mqtt.connected()){
    if (mqtt.publish((char*)topicSever, (uint8_t*)dataload,sizeof(dataload))){
      #ifdef DEBUG
        // dbSerial.println("Data Send Ok ");
        // dbSerial.println(millis()/1000);
      #endif // DEBUG
      WifiConnected = true;
    } else{
    //  debug("Data Send failure! ");
    WifiConnected = false;
    }
  }
}
void wifi_mqtt_process() {
  // if(gdata.rssiWF==0){
  //   cntDisconnect++;
  //   if(cntDisconnect>1000) ESP.restart();    
  // }
  if((gdata.rssiWF>gdata.lowRssiWiFi)&(gdata.rssiWF!=0))
  {
    if(mqtt.connected())  {
    sendToSever();
    #ifdef DEBUG
      dbSerial.println("Wifi Send: "); 
      for(int i=0;i<numBytes;i++){
        sendHexPC(dataload[i]);
      }
      dbSerial.println();
    #endif // DEBUG     
    }
    cntDisconnect = 0;
  }
  else {
    debug("Wifi poor, not send");
  }
}
/*************************************** EC200 - 4G BEGIN ***************************/
void init_4G() {  
  String txt;
  //this use for 4G modem
  gsm.begin(&Serial2,115200);
  //assign pin control power on, different power enable
  gsm.SetPowerKeyPin(PWR_KEY);
  //command ping power on
 // gdata.rssi4G = gsm.SignalQuality();
 // if((gdata.rssi4G==0)|(gdata.rssi4G>=99)) 
 txt = gsm.GetIMEI();
 if(txt=="") gsm.PowerOn(); 
  //wait 4G connection ready
  // timeDelay4G = millis();
  // delay4Ginit();  
  // delay(8000);
  // //gsm.WaitReady();
  // txt = gsm.GetIMEI();
  txt = gsm.GetIMEI();
  for(int i=0;i<15;i++)IMEI[i]=txt[i];
  // debug(txt);
  gdata.rssi4G = gsm.SignalQuality();
  #ifdef DEBUG
    // dbSerial.println(F("IMEI: "));
    // dbSerial.println(txt);
    // dbSerial.println(F("GetOperator --> "));
    // dbSerial.println(gsm.GetOperator());
    // dbSerial.println(F("SignalQuality --> "));
    // gdata.rssi4G = gsm.SignalQuality();
  // gdata.rssi4G = gsm.SignalQuality();
  // dbSerial.println(gdata.rssi4G);
  // //delay(500);
  #endif
}
void readRSSI4G(){
  gdata.rssi4G = gsm.SignalQuality();
  if(gdata.rssi4G==0) gdata.rssi4G = gsm.SignalQuality();
}
void sendToSever4G()  {
  // if(autoInit4G==1){
    //this section send via 4G modem
    // #ifdef DEBUG
    //   dbSerial.println(F("GetOperator --> "));
    //   dbSerial.println(gsm.GetOperator());
    //   dbSerial.println(F("SignalQuality --> "));
      //gdata.rssi4G = gsm.SignalQuality();
      
    //   // //delay(500);
    // #endif
    // check rssi4G
    // if(gdata.rssi4G==0) gdata.rssi4G = gsm.SignalQuality();
    // //   gdata.rssi4G = gsm.SignalQuality();
    //   debug(String(gdata.rssi4G));
    readRSSI4G();
    //if(gdata.rssi4G<25)return;
    if((gdata.rssi4G==0)|(gdata.rssi4G>=100)) {
      init_4G();
    //   net4Gconnected = false;
    //   return;
    }
    /* if wifi mqtt connected  send 300s, else 30s send again*/
    // numTimeSend4G++;
    if((WiFi.status() == WL_CONNECTED)&(mqtt.connected()))
    {
      if((millis()<300000)&(numTimeSend4G>30)){
        numTimeSend4G=0;
      }
      else if(numTimeSend4G>300){
        numTimeSend4G = 0;
      }
      else return;
    }
    else if (numTimeSend4G>50)
    {
      numTimeSend4G = 0;
    }
    else {
      return;
    }
    //open Mqqtt
    gsm.my_flush();
    // gsm.MQTT_setup(Esp8266ID,(char*)topicSever4G,String("A9"));
    // if(0 == gsm.MQTT_Open((char*)mqtt_server_test, mqtt_port_test, (char*)Esp8266ID, (char*)topicSever4G,(char*) mqttUser,(char*)mqttPassword))
    // if(0 == convert_u8_hex(dataload,HexString,sizeof(dataload)))  {
    //   dbSerial.print(F("Data HEX String:"));
    //   dbSerial.print((char*)HexString);
    //   dbSerial.println("");
    // }
    // else
    //   dbSerial.println(F("Convert data to HEX string failed"));

    if(0 == gsm.MQTT_Open((char*)mqttServer, mqttPort, (char*)ESP_ID, (char*)topicSever4G,(char*) mqttUser,(char*)mqttPassword))
      debug(F("Open Mqtt 4G OK"));
    else
      debug(F("Open Mqtt 4G False"));

    // if(0 == gsm.MQTT_Publish((char*)txt_subscribe, (char*)topicSever4G, (char*)HexString, sizeof(HexString))) {
    // if(0 == gsm.MQTT_Publish((char*)topicSever4G, "123456789901234567890123456789", numBytes)) {
    if(0 == gsm.MQTT_Publish((char*)txt_subscribe, (char*)topicSever4G, (char*)HexString, lenHexString)) {
      debug(F("Send Mqtt 4G OK"));
      net4Gconnected = true;
      debug((char*)HexString);
    } 
    else{
      // dbSerial.println(F("Send Mqtt 4G False"));
      net4Gconnected = false;
    }
    //gsm.MQTT_setup(Esp8266ID,(char*)topicSever4G,String((char*)dataload));
    // dbSerial.println(F("Send data 4G"));
    //send SUB to recieve command

    //send PUB to server

    //close mqtt port
    //gsm.MQTT_Close();
  // }
  // else {
  //   delay4Ginit();
  // }
}
/*************************************** EN200 - 4G END ************************/
int key_press(){
  int key_adc = analogRead(KEY_IN);
  if((key_adc>1500)&(key_adc<2200)){  // Key MODE 1.65V = 1840 1897   1800
    return(KEY_MODE);
  }
  else if((key_adc>2300)&(key_adc<2770)){  // Key BELL 2.24V = 2560 2645  2500 2738
    return(KEY_BELL);
  }
  else if((key_adc>2770)&(key_adc<3500)){  // Key CHECK 2.51V = 2900 2991 2850
    return(KEY_CHECK);
  }
  // else if((key_adc>2000)&(key_adc<2050)){  // Key BELL + CHECK 2090
  //   return(KEY_B_C);
  // }
  // else if((key_adc>1520)&(key_adc<1620)){  // Key MODE + CHECK = 1574
  //   return(KEY_M_C);
  // }
  // else if((key_adc>1400)&(key_adc<1510)){  // Key MODE + BELL = 1460
  //   return(KEY_M_B);
  // }
  // else if((key_adc>1200)&(key_adc<1350)){  // Key MODE+BELL+CHECK = 1280
  //   return(KEY_M_B_C);
  // }
  else {
    return 0;
  }
}
int autoPower(){  
  uint16_t ch_ac_adc = analogRead(CH_AC);  
  VBAT_ON; 
  gdata.pwStatus = 0;  // 
  // gdata.pwStatus = PW_BAT;
  if(ch_ac_adc<2500){  // AC OK -  Adapter in
    gdata.pwStatus |= PW_ACIN;
    if(digitalRead(CHARGE)){
      gdata.pwStatus |= PW_CHARG;
      if(ch_ac_adc>1600){  // Full of Battery
        holdCharg++;
        if(holdCharg>100000) CHARGE_OFF;
      }
      else {
        holdCharg = 0;
      }
    }
    
    if((gdata.powerBAT == 0)&(gdata.batVoltage<800)){  // Charging when Vbat < 8.00
      CHARGE_ON;
      holdCharg = 0;
    } 
    if((millis()-timeLoopBAT>timeAutoBat)&(gdata.powerBAT == 0)){
      timeLoopBAT = millis();
      gdata.powerBAT = 1;
    }
    if((gdata.powerBAT)&(gdata.batVoltage>820)){ // Power by Battery
      gdata.pwStatus |= PW_BAT;    
      if(gdata.batVoltage<gdata.VolLowPwBAT) {
        gdata.powerBAT = 0;
        VBAT_OFF;
        timeLoopBAT = millis();
      }
      //else VBAT_ON;
    }   
  }
  else{
    gdata.pwStatus |= PW_BAT;
  }

  if(gdata.pwStatus & PW_BAT) {
    if(digitalRead(CHANGE)) CHARGE_OFF;
    VBAT_ON; 
  } else VBAT_OFF;
  VBAT_ON; 
  // gdata.pwStatus |= ((gdata.batVoltage-640)/20)<<4;
  if(gdata.batVoltage>=650)gdata.pwStatus |= BAT_OK;
}
void select_line(int line){
  int outLine;
  if(line<8)outLine = 7-line;
  else outLine = line;
  digitalWrite(SA0,bitRead(outLine,0));
  digitalWrite(SA1,bitRead(outLine,1));
  digitalWrite(SA2,bitRead(outLine,2));
  digitalWrite(SA3,bitRead(outLine,3));
  delay(2);
}
void read_sensor(){
  int line;
  for(line=0;line<16;line++){
    select_line(line);
    if(bitRead(gdata.lineNotUse,line))gdata.lineStatus[line]=NOT_USE; // ==NOT_USE
    else{
      if(digitalRead(INSEN)==LOW) gdata.lineStatus[line] = 0;
      else gdata.lineStatus[line] = (digitalRead(EOLINE) + digitalRead(INSEN)*2);
    }
  }
}
void data_process(){
  Vbat = analogRead(VBAT_FB)+150;
  // cntAdc++;
  // if(cntAdc>9){
    // Vbat = Vbat/10 + 150;
    gdata.batVoltage = Vbat/3-Vbat/80;
  //   Vbat = 0;
  //   cntAdc=0;
  // }
  // gdata.batVoltage = 
  //if()bitSet(gdata.Status,)
  // gdata.Status = 123;
  read_sensor();
}
void checkLineStatus(){
  uint8_t line;  
  // gdata.zoneArlam=0;
  // gdata.zoneWarning=0;
  for(line=0;line<numLine;line++){  
    if(bitRead(gdata.lineNotUse,line)){
        gdata.holdStatus[line] = NOT_USE;
        bitClear(gdata.zoneArlam,line);
        bitClear(gdata.zoneWarning,line);
    }
    else{   // Use line for check Alarm
      if (gdata.lineStatus[line] == ALARM){ // Detect Sensor active
        if(gdata.keySensor[line]!=ALARM){ 
          gdata.keySensor[line] = ALARM;
          gdata.timeHold[line] = 1;
        }
        else {  // keySensor = ALARM
          gdata.timeHold[line]++;
          if(gdata.timeHold[line]>=TIME_HOLD_SENSOR){
            gdata.timeHold[line]=TIME_HOLD_SENSOR;
            gdata.holdStatus[line] = ALARM;
            bitSet(gdata.zoneArlam,line);
          }
        }
      }
      else if (gdata.lineStatus[line] == ENDOFLINE){ // Detect Sensor OEL
        if(gdata.keySensor[line]!=ENDOFLINE){
          gdata.keySensor[line] = ENDOFLINE;
          gdata.timeHold[line] = 1;
        }
        else {  // keySensor = ENDOFLINE
          gdata.timeHold[line]++;
          if(gdata.timeHold[line]>=TIME_HOLD_SENSOR){
            gdata.timeHold[line]=TIME_HOLD_SENSOR;
            gdata.holdStatus[line] = ENDOFLINE;
            bitSet(gdata.zoneWarning,line);
          }
        }
      }  
      else {
        gdata.timeHold[line]=0;
        gdata.holdStatus[line] = NORMAL; 
        gdata.keySensor[line] = NORMAL;  
        bitClear(gdata.zoneArlam,line);
        bitClear(gdata.zoneWarning,line);
      }
    }  
  }
}
void checkAlarm(){
  int line;
  // uint32_t timeCheckAlarm;
  timeCheckAlarm = millis()-timeLoopAlarm;
  if(millis()-timeLoopAlarm>timeAlarm){
    timeLoopAlarm = millis();
    timeAlarm = timeAlarmOn + timeAlarmOff;
    //timeCheckAlarm = 0;
  }
  gdata.Status = NORMAL;
  for(line=0;line<numLine;line++){
    if(gdata.holdStatus[line]==ENDOFLINE){
      gdata.Status = ENDOFLINE;
    }
  }
  for(line=0;line<numLine;line++){
    if(gdata.holdStatus[line]==ALARM){
      gdata.Status = ALARM;   
    }
  }
  
  // Output Relay
  if(gdata.Status==ALARM){
    gdata.LEDStatus = 1;
    if(timeCheckAlarm < timeAlarmOn){
      //BELL_ON;
      if(gdata.enableBell){
        BELL_ON;
        BEEP_ON;
      }
      // else BELL_OFF;
    }
    else {
      BELL_OFF;
      BEEP_OFF;
    }
    if((digitalRead(RF_REMOTE))|(key_press()==KEY_BELL)){
      if(keyBell==0){
        gdata.enableBell=!gdata.enableBell;
        keyBell = 1;
        if(gdata.enableBell){
          BELL_ON;
          BEEP_ON;
        }
        else {
          BELL_OFF;
          BEEP_OFF;
        }
      }
    }
    else keyBell = 0;
    LAMP_ON;
    OUT1_ON;
    OUT2_ON;
  }
  else {    
    if(gdata.Status==ENDOFLINE){      
    }
    gdata.enableBell= 1;
    gdata.LEDStatus = 2;
    BELL_OFF;
    LAMP_OFF;
    OUT1_OFF;
    OUT2_OFF;
    BEEP_OFF;
  }
  
}
void updateData2Sent(){
  uint16_t index=0; 
  uint8_t line;
  gdata.batPercent = (gdata.batVoltage-640)/2;
  if(gdata.batPercent>100)gdata.batPercent=100;
  gdata.rssiWF = WiFi.RSSI();

  dataload[index++] = numBytes;           // 0
  for(line=0;line<12;line++) dataload[index++] = ESP_ID[line];
  for(line=0;line<15;line++) dataload[index++] = IMEI[line];
  dataload[index++] = gdata.rssiWF;       // 28
  dataload[index++] = gdata.rssi4G;       // 29
  dataload[index++] = gdata.pwStatus;     // 30
  // dataload[index++] = gdata.batVoltage/256;
  // dataload[index++] = gdata.batVoltage%256;
  dataload[index++] = gdata.batPercent;   // 31
  dataload[index++] = gdata.Status;       // 32
  dataload[index++] = numLine;            // 33
  for(line = 0; line < numLine; line++)
  {    
  //  index = byteOfHeader + line * byteOfLine - 1;
    dataload[index++]= gdata.lineStatus[line];
  }
  dataload[index++]  = (gdata.zoneArlam>>24)&0xFF;  //48
  dataload[index++]  = (gdata.zoneArlam>>16)&0xFF;  //49
  dataload[index++]  = (gdata.zoneArlam>>8)&0xFF;   //50  
  dataload[index++]  = (gdata.zoneArlam)&0xFF;      //51

  dataload[index++]  = (gdata.zoneWarning>>24)&0xFF;  //52
  dataload[index++]  = (gdata.zoneWarning>>16)&0xFF;  //53
  dataload[index++]  = (gdata.zoneWarning>>8)&0xFF;   //54
  dataload[index++]  = (gdata.zoneWarning)&0xFF;      //55
  //dataload[0] = numBytes;
  // memset(HexString,0,sizeof(HexString));
  index = 0;
  index = updateHexString(dataload[0],index);
  for(line=0;line<27;line++) {  // ID and IMEI
    HexString[index++] = dataload[line+1];
  }
  for(line=28;line<numBytes;line++)
  {
    index = updateHexString(dataload[line],index);
  }
  lenHexString = index;
}
void LED_Status(uint16_t cnt){
    if(deviceStatus==0){ // don't connect to wifi
      if(cnt%5==0){
        LEDG_TOGGLE;  
      }
      if(WiFi.status() == WL_CONNECTED){
        deviceStatus = 1;
        BEEP_OFF;
      }
      else if((net4Gconnected==false)&(gdata.Status!=ALARM)){        
        if(BUZZER_EN){
          if((cnt/5)%20==0)BEEP_TOGGLE;
          else BEEP_OFF;
        }        
      }
    }
    else if (deviceStatus==1){
      if (in_smartconfig == false){
        if((gdata.rssiWF<-30)&(gdata.rssiWF>-80)){
          int x = (110 + gdata.rssiWF)/4;
          if(cnt%20<x) LED_ON();
          else LED_OFF();
        }
        else{
          if(cnt%20<1) LED_ON();
          else LED_OFF();
        }
      }      
    }
    if(gdata.Status==NORMAL){
      LEDG_ON; LEDR_OFF;
    }
    else if(gdata.Status==ALARM){
      LEDR_ON; LEDG_OFF;
    }
    else if(gdata.Status==ENDOFLINE){
      LEDG_ON;
      if (cnt%2)
      {
        LEDR_TOGGLE;
      }      
    }
}
void taskStatus(void * xTaskParameters){
  while(1){    
    if((numTask1==0)&(millis()<100000)){
      esp_task_wdt_init(10, true); //enable panic so ESP32 restarts
      esp_task_wdt_add(NULL); //add current thread to WDT watch
    }
    numTask1++;
    //smartUpdateOTA();
    //smartConfig();
    data_process();
    checkLineStatus();
    autoPower();
    if(gdata.startCheckAlarm) checkAlarm(); 
    else{
      BELL_OFF;
      LAMP_OFF;
      OUT1_OFF;
      OUT2_OFF;
    }
    if(numTask1>20){
      if(digitalRead(RF_REMOTE))rfOk = true;
      else rfOk=false;    
    }
    if((numTask1%10)==0){
      updateData2Sent();
      keyTest = key_press();   
      sendToPCTest();   
      esp_task_wdt_reset();
      // Serial.print("Task Status is running on core ");
      // Serial.println(xPortGetCoreID());
    }    
    if (((numTask1%TIME_WIFI)==0))
    {
      wifi_mqtt_process();     
    }
    if((gdata.startCheckAlarm==0)&((numTask1%50)==0))gdata.startCheckAlarm=1;
    gdata.relayStatus = (uint8_t)(digitalRead(LAMP)<<3 + digitalRead(BELL)<<2 + digitalRead(RL_OUT2)<<1 + digitalRead(RL_OUT1));
    LED_Status(numTask1);
    vTaskDelay(TIME_CHECK_STATUS/portTICK_PERIOD_MS);
  }
}
void taskOne( void * parameter )
{
    
    for( int i = 0;i<10;i++ ){
 
        Serial.println("Hello from task 1");
        delay(1000);
    }
    // Serial.println("Ending task 1");
    // vTaskDelete( NULL );
}
uint8_t check_crc_data (uint8_t data[], uint8_t len){
    uint8_t crc = 0;    
    for (uint8_t i = 0; i< len; i++)
    {
        crc += data[i];
    }
    
    if (crc == data[len])
    {
        return 1;
    }
    return 0;
}
/************************************** CALL BACK *******************************/
void callback(char* topic, byte* payload, unsigned int length) {
  unsigned int addSave,i,j;
  dbSerial.print("Message arrived: ");
  dbSerial.println(topic);
 
   dbSerial.print("Message len:");  dbSerial.print(length); dbSerial.print(" ");
  for (i = 0; i < length; i++) {
     dbSerial.print((char)payload[i],HEX);
     dbSerial.print(" ");
  }
  
 if((payload[0]==0x68)&&(payload[1]==36))   {    // update Setting gdata
   for (i = 0; i < numLine; i++) {
     addSave = EEPROM_SETTING + i*2;
     for(j=0;j<2;j++){ // numByte need change bit (uint32 = 4 byte)
       eepRead.uint8[1-j] = payload[i*2+j+2];
     }
     EEPROM.write(addSave,eepData.uint8[0]);
     EEPROM.write(addSave+1,eepData.uint8[1]);
    //  EEUpdate4byte(addSave,eepRead.uint32[0]);
   }
   EEPROM.commit();    //Store data to EEPROM   
   dbSerial.println("Update data"); 
  //  read_data_EE_EVM();
 }
//  else if((payload[0]==0x69)&&(payload[1]==36))   { // update CMD for kWh Read 
//    for (i = 0; i < numLine; i++) {
//      addSave = EE_ADD_EVM + numLine*4 + i*4;
//      for(j=0;j<4;j++){                             // numByte need change bit (uint32 = 4 byte)
//        eepRead.uint8[3-j] = payload[i*4+j+2];
//      }
//      EEUpdate4byte(addSave,eepRead.uint32[0]);
//    }
//    CMDUpdate = 1;
//  }
//  else if((payload[0]==0x56)&&(payload[1]==0x24))   { // update CMD for kWh after power cut off
//    for (i = 0; i < numLine; i++) {
//      addSave = EE_ADD_EVM + numLine*8 + i*4;      // 72 + phase*4 bytes
//      for(j=0;j<4;j++){                             // numByte need change bit (uint32 = 4 byte)
//        eepRead.uint8[3-j] = payload[i*4+j+2];
//      }
//      EEUpdate4byte(addSave,eepRead.uint32[0]);
//      CMDUpdate = 1;
//    }
//    EEPROM.commit();    //Store data to EEPROM   
//    dbSerial.println("Update data"); 
//    read_data_EE_EVM();
//  }
//  else if((payload[0]==0x55)&(payload[1]==11)){
//    clearEepromEmeter();
//    ESP.restart();
//  }  
//  else if((payload[0]==0x50)&(payload[1]==1)){
////    clearEepromEmeter();
//    ESP.restart();
//  }
  
   dbSerial.println();
   dbSerial.println("-----------------------");
}
/*************************************** EEPROM *********************************/
void GSafe_Setting_Save(){
  uint16_t add = EEPROM_SETTING;
  uint16_t i=0;//,byte;
  EEPROM.write(EEPROM_SETTING-1,0x01);
  eepData.uint16[i++] = timeAlarmOn;
  eepData.uint16[i++] = timeAlarmOff;
  eepData.uint16[i++] = timeActiveAlarm;
  eepData.uint16[i++] = gdata.timeCounter;
  eepData.uint16[i++] = gdata.VolLowPwBAT;
  eepData.uint16[i++] = gdata.lineNotUse;
  // byte = (i-1)*2;
  for(i=0;i<numBytesSave;i++){
    EEPROM.write(add+i,eepData.uint8[i]);
  }
  EEPROM.commit();
}
void GSafe_Setting_Read(){
  uint16_t add = EEPROM_SETTING;
  int16_t i;//,byte=numBytesSave;
  for(i=0;i<numBytesSave;i++){
    eepData.uint8[i] = EEPROM.read(add+i);
  }
  timeAlarmOn = eepData.uint16[0];
  timeAlarmOff = eepData.uint16[1];
  timeActiveAlarm = eepData.uint16[2];
  gdata.timeCounter = eepData.uint16[3];
  gdata.VolLowPwBAT = eepData.uint16[4];
  gdata.lineNotUse = eepData.uint16[5];
  if((timeAlarmOn==0xFFFF)&(timeAlarmOff==0xFFFF)&(timeActiveAlarm==0xFFFF)&(gdata.timeCounter==0xFFFF)&(gdata.VolLowPwBAT==0xFFFF)) initStart(1);
}
void write_EEPROM_Wifi(){
  // uint16_t add = EEPROM_SETTING;
  uint16_t i=0;//,byte;
  String qsid = WiFi.SSID();
  String qpass = WiFi.psk();
  if (qsid.length() > 0 && qpass.length() > 0) {
    debug("clearing eeprom");
    for (i = 0; i < 96; ++i) {
      EEPROM.write(i, 0);
    }
    debug(qsid);
    debug(qpass);
    debug("writing eeprom ssid:");
    for (i = 0; i < qsid.length(); ++i)
    {
      EEPROM.write(i, qsid[i]);
      #ifdef DEBUG
      Serial.print("Wrote: ");
      Serial.println(qsid[i]);
      #endif // DEBUG
    }
    debug("writing eeprom pass:");
    for (i = 0; i < qpass.length(); ++i)
    {
      EEPROM.write(32 + i, qpass[i]);
      #ifdef DEBUG
      Serial.print("Wrote: ");
      Serial.println(qpass[i]);
      #endif // DEBUG      
    }
    EEPROM.commit();
    delay(100);
    ESP.restart();
  }
}
void write_EEPROM_Wifi_default(){
  // uint16_t add = EEPROM_SETTING;
  uint16_t i=0;//,byte;
  debug("clearing eeprom");
  for (i = 0; i < 96; ++i) {
    EEPROM.write(i, 0);
  }
  debug("writing eeprom ssid:");
  for (i = 0; i < sizeof(ssid); ++i)
  {
    EEPROM.write(i, ssid[i]);
    #ifdef DEBUG
    Serial.print("Wrote: ");
    Serial.println(ssid[i]);
    #endif // DEBUG
  }
  debug("writing eeprom pass:");
  for (i = 0; i < sizeof(password); ++i)
  {
    EEPROM.write(32 + i, password[i]);
    #ifdef DEBUG
    Serial.print("Wrote: ");
    Serial.println(password[i]);
    #endif // DEBUG      
  }
  EEPROM.commit();
  delay(200);
  ESP.restart();
}
uint8_t read_EEPROM_Wifi(){
  String esid;
  for (int i = 0; i < 32; ++i)
  {
    esid += char(EEPROM.read(i));
  }
  #ifdef DEBUG
  Serial.println();
  Serial.print("SSID: ");
  Serial.println(esid);
  Serial.println("Reading EEPROM pass");
  #endif // DEBUG
 
  String epass = "";
  for (int i = 32; i < 96; ++i)
  {
    epass += char(EEPROM.read(i));
  }
  #ifdef DEBUG
  Serial.print("PASS: ");
  Serial.println(epass);
  #endif // DEBUGSend Mqtt 4G OK
  WiFi.begin(esid.c_str(), epass.c_str());
}
// void checkMode(){
//   uint16_t index=0; 
//   uint8_t line, dataCom[60];
//   dataCom[index++]='I';
//   dataCom[index++]='D';
//   dataCom[index++]=':';
//   for(line = 1; line < 48; line++)
//   {    
//     dataCom[index++]= dataload[line];
//   }
//   dataCom[index++] = gdata.relayStatus;
//   for(line=0; line<index;line++)  dbSerial.write(dataCom[line]); 
// }
