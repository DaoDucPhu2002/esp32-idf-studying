#include "main.h"

#define TIME_LOOP  1000
uint32_t loop_mqtt,looptest;
uint16_t numUpdate;


void setup() {
  in_smartconfig = false;
  Serial.begin(115200);
  Serial2.begin(115200, SERIAL_8N1, RXD2, TXD2);
  xTaskCreate(taskStatus,"TaskStatus",20000,NULL,1,NULL);
  // xTaskCreatePinnedToCore(taskStatus,"TaskStatus",20000,NULL,1
  sendTimePC("Start: ", millis()/1000);
  // 
  InitIO(); 
  LAMP_ON;
  sendTimePCln("Init Wifi: ", millis()/1000);
  macRead(); 
  BEEP_OFF;
  char x = EEPROM.read(1);
  if((x<30)|(x>122))write_EEPROM_Wifi_default();
  else read_EEPROM_Wifi();
  WiFi_Connect();
  sendTimePCln("Init 4G: ", millis()/1000);
  
  init_4G();
  sendTimePCln("Init done: ", millis()/1000);
  data_process();
  updateData2Sent();
  sendToPC();
  // esp_task_wdt_init(10, true); //enable panic so ESP32 restarts
  // esp_task_wdt_add(NULL); //add current thread to WDT watch
}
void testAdc(){
  int adc;
  if(millis()-looptest>1000){
    looptest = millis();
    adc = analogRead(CH_AC);
    sendTimePC(" CH_AC:",adc); 
    adc = analogRead(KEY_IN);
    sendTimePC(" KEY_IN:",adc); 
    adc = analogRead(VBAT_FB);
    sendTimePCln(" VBAT_FB:",adc); 
  }
}
void testIO(int x){
  if(x){
    digitalWrite(SA0,HIGH);
    digitalWrite(SA1,HIGH);
    digitalWrite(SA2,HIGH);
    digitalWrite(SA3,HIGH);
    digitalWrite(LAMP,HIGH);
    digitalWrite(BELL,HIGH);
    digitalWrite(RL_OUT1,HIGH);
    digitalWrite(RL_OUT2,HIGH);
  }
  else{
    digitalWrite(SA0,LOW);
    digitalWrite(SA1,LOW);
    digitalWrite(SA2,LOW);
    digitalWrite(SA3,LOW);
    digitalWrite(LAMP,LOW);
    digitalWrite(BELL,LOW);
    digitalWrite(RL_OUT1,LOW);
    digitalWrite(RL_OUT2,LOW);
  }
}
void testLine(int x){
  select_line(x);
  delay(50);
  dbSerial.print("Line: ");dbSerial.print(x);
  dbSerial.print(" EOL:");dbSerial.print(digitalRead(EOLINE));
  dbSerial.print(" ALR:");dbSerial.println(digitalRead(INSEN));
}

void test_imei(){
  String txt = gsm.GetIMEI();
  debug(txt);
}

void loop() {
  smartUpdateOTA();
  // status4G();
  if ((millis() - loop_mqtt) > TIME_LOOP) {   // 1 sec
    loop_mqtt = millis();
    // data_process();
    // checkFireStatus();
    // updateData2Sent();
    // sendToPC();
    // testAdc();
    // numUpdate++;
    // readRSSI4G();
    numTimeSend4G++;
    // esp_task_wdt_reset();
    // sendToPCTest();
    #ifdef DEBUG
      //sendToPC();
      // sendToPCTest();
      #else
      sendToPCTest();
      #endif // DEBUG      
     if(numTimeSend4G%10==0){    // 10s= check send to Sever by 4G
     /* if wifi mqtt connected  send 300s, else 30s send again = edit in sendToSever4G()*/
      sendToSever4G();
      // Serial.print("Task main is running on core ");
      // Serial.println(xPortGetCoreID());
      // dbSerial.print("Finish Send to Sever: ");dbSerial.println(millis()/1000);
     }
    //  #ifndef DEBUG
    //     sendToPCTest();
    //   #endif // !DEBUG  
    // testLine(numUpdate%16);
  }  
}